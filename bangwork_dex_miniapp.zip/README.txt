Bangwork DEX Telegram Mini App starter.
This is frontend only; it does not execute real trades.
Host the folder on HTTPS, then paste the URL into BotFather -> Configure Mini App.
