BANGWORK DEX BOT BACKEND

This backend makes @Nasavillabot respond to /start and other commands.

IMPORTANT:
- Never put your Telegram Bot Token inside the code.
- Set BOT_TOKEN as a private environment variable in your hosting provider.
- MINI_APP_URL is already set to the Netlify Mini App.

Render:
1. Upload this project to a GitHub repository.
2. Create a Render Background Worker from the repository.
3. Build command: pip install -r requirements.txt
4. Start command: python bot.py
5. Add environment variable BOT_TOKEN = your BotFather API token.
6. Deploy.
