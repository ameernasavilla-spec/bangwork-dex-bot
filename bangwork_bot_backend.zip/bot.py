import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(level=logging.INFO)

TOKEN = os.environ["BOT_TOKEN"]
MINI_APP_URL = os.environ.get(
    "MINI_APP_URL",
    "https://rainbow-duckanoo-c500e5.netlify.app"
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [[
        InlineKeyboardButton(
            "🚀 Open Bangwork DEX",
            web_app=WebAppInfo(url=MINI_APP_URL)
        )
    ]]
    await update.message.reply_text(
        "🚀 Welcome to Bangwork DEX!\n\n"
        "⚡ Multi-chain trading terminal\n"
        "🔐 Non-custodial interface",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Bangwork DEX Commands:\n\n"
        "/start - Open Bangwork DEX\n"
        "/buy - Buy a token\n"
        "/sell - Sell a token\n"
        "/wallet - Connect wallet\n"
        "/orders - View orders\n"
        "/chart - View token chart\n"
        "/alerts - Price alerts\n"
        "/chain - Select blockchain\n"
        "/settings - Trading settings\n"
        "/help - Get help"
    )

async def placeholder(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚧 This feature is being connected. Please use Open Bangwork DEX for the current interface."
    )

def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    for command in ["buy", "sell", "wallet", "orders", "chart", "alerts", "chain", "settings"]:
        app.add_handler(CommandHandler(command, placeholder))
    app.run_polling()

if __name__ == "__main__":
    main()
